# Architecture
The frontend is a Next.js app, the backend is an Express/WebSocket service, SQLite stores platform metadata, and connectors provide normalized external-service actions.
