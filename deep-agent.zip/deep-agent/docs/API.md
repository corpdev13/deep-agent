# API
All `/api` routes require `x-license-key`. Chat sessions stream over `/ws`; REST routes cover files, balance, skills, connectors, storage, deploy, and checkpoints.
