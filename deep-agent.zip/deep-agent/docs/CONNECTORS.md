# Connectors
Catalog JSON files describe authentication, base URLs, and actions. Credentials are stored separately from catalog metadata.
