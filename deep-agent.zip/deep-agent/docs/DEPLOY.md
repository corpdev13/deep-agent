# Deployment
Push to GitHub, deploy the backend to Railway and frontend to Vercel, configure Neon and R2 variables, then apply sandbox and `deploy/k8s` manifests with kubectl. Verify using the configured license key.
