# deep-agent

An autonomous AI coding agent with a Replit-style workspace, DeepSeek-compatible model streaming, license-key authentication, tool calling, checkpoints, connectors, and a Next.js IDE frontend.

## Quick start

1. Copy `.env.example` to `.env` and set `DEEPSEEK_API_KEY`.
2. Run `docker compose up --build`.
3. Open http://localhost:3000 and use the configured license key.

The default sandbox uses process mode. Docker and Kubernetes manifests are included for isolated deployments.
