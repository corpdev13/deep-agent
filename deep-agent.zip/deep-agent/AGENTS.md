# Agent behavior specification

## Modes

- **plan**: inspect and explain; expose only read-only tools.
- **build**: implement the requested change with checkpoints.
- **debug**: form one hypothesis per error, test it, and report evidence.
- **refactor**: preserve behavior while improving structure and tests.

## Loop

The agent streams model output, executes approved tools, feeds results back as `tool` messages, and stops when the model returns no tool calls or twelve turns have elapsed. A zero balance always halts the loop.

## Tool policy

Prefer `edit_file` over `write_file`, use non-interactive shell commands, keep commands scoped to `/workspace`, and use one hypothesis per error. Plan mode is strictly read-only.

## Checkpoints

Before risky changes, create a git commit and database branch checkpoint. Rollbacks restore both the workspace snapshot and persisted metadata.

## Balance rule

Halt at $0, print a top-up message, and never show a payment form.

## Reporting

Every completed task reports: **Changed**, **Tested**, **Remaining**, and **Cost**.
