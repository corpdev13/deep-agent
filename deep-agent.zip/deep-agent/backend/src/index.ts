import 'dotenv/config';
import { createServer } from 'node:http';
import { app } from './server.js';
import { attachWebSocket } from './ws.js';
const server = createServer(app);
attachWebSocket(server);
server.listen(Number(process.env.PORT ?? 8080), '0.0.0.0', () => console.log(`deep-agent backend listening on ${process.env.PORT ?? 8080}`));
