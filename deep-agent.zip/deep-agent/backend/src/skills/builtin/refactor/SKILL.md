# refactor skill
Guidance for working with refactor projects, including validation and safe incremental changes.
