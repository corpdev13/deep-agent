# svelte skill
Guidance for working with svelte projects, including validation and safe incremental changes.
