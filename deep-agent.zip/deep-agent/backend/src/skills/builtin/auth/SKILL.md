# auth skill
Guidance for working with auth projects, including validation and safe incremental changes.
