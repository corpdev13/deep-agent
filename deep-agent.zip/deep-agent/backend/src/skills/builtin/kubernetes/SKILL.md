# kubernetes skill
Guidance for working with kubernetes projects, including validation and safe incremental changes.
