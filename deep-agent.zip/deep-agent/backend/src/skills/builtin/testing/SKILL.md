# testing skill
Guidance for working with testing projects, including validation and safe incremental changes.
