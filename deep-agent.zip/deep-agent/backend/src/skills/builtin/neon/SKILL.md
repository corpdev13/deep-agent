# neon skill
Guidance for working with neon projects, including validation and safe incremental changes.
