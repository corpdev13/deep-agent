# go skill
Guidance for working with go projects, including validation and safe incremental changes.
