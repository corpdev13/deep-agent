# api-design skill
Guidance for working with api-design projects, including validation and safe incremental changes.
