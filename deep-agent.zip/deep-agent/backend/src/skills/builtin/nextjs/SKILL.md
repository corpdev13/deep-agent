# nextjs skill
Guidance for working with nextjs projects, including validation and safe incremental changes.
