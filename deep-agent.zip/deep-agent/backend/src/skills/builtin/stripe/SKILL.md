# stripe skill
Guidance for working with stripe projects, including validation and safe incremental changes.
