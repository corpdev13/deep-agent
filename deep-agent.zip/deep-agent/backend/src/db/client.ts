import Database from 'better-sqlite3';
import fs from 'node:fs';
const path = process.env.DB_PATH ?? './data/deep-agent.sqlite';
fs.mkdirSync(path.split('/').slice(0,-1).join('/') || '.', {recursive:true});
export const db = new Database(path);
db.exec(`CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY, session_id TEXT, role TEXT, content TEXT, cost REAL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP); CREATE TABLE IF NOT EXISTS credentials (connector_id TEXT PRIMARY KEY, payload TEXT NOT NULL); CREATE TABLE IF NOT EXISTS checkpoints (id TEXT PRIMARY KEY, session_id TEXT, label TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);`);
export function saveMessage(sessionId:string, role:string, content:string, cost=0){ db.prepare('INSERT INTO messages(session_id,role,content,cost) VALUES(?,?,?,?)').run(sessionId,role,content,cost); }
