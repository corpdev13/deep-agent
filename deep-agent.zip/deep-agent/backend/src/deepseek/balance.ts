export async function getBalance(): Promise<number> {
  const base = process.env.DEEPSEEK_BASE_URL ?? 'https://api.deepseek.com';
  const response = await fetch(`${base}/user/balance`, { headers: { authorization: `Bearer ${process.env.DEEPSEEK_API_KEY ?? ''}` } });
  if (!response.ok) return 0;
  const payload: any = await response.json();
  return Number(payload.balance_infos?.find((item: any) => item.currency === 'USD')?.total_balance ?? payload.total_balance ?? 0);
}

export function startBalancePoller(emit: (amount: number) => void) {
  const tick = async () => emit(await getBalance());
  void tick();
  return setInterval(tick, 60_000);
}
