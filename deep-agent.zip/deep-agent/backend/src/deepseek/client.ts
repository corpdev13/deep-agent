export type Message = {role:string; content?:string; tool_calls?:unknown[]; tool_call_id?:string; name?:string};
export async function* streamChat(model:string, messages:Message[], tools:unknown[] = []) {
  const base = process.env.DEEPSEEK_BASE_URL ?? 'https://api.deepseek.com';
  const r = await fetch(`${base}/chat/completions`, {method:'POST', headers:{'content-type':'application/json',authorization:`Bearer ${process.env.DEEPSEEK_API_KEY ?? ''}`}, body:JSON.stringify({model,messages,tools,stream:true})});
  if(!r.ok) throw new Error(`DeepSeek request failed: ${r.status}`);
  const reader = r.body?.getReader(); if(!reader) return; const decoder = new TextDecoder(); let buf='';
  while(true){ const {done,value}=await reader.read(); if(done) break; buf += decoder.decode(value,{stream:true}); const lines=buf.split('\n'); buf=lines.pop() ?? ''; for(const line of lines){ if(!line.startsWith('data:')) continue; const data=line.slice(5).trim(); if(data==='[DONE]') return; try{ yield JSON.parse(data); }catch{} } }
}
