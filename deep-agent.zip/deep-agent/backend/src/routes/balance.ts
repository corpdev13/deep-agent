import {Router} from 'express'; export const balanceRouter=Router(); balanceRouter.get('/balance', (_req,res)=>res.json({ok:true,resource:'balance'}));
