import {Router} from 'express'; export const skillsRouter=Router(); skillsRouter.get('/skills', (_req,res)=>res.json({ok:true,resource:'skills'}));
