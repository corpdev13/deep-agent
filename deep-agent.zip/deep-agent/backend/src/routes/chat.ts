import {Router} from 'express'; export const chatRouter=Router(); chatRouter.get('/chat', (_req,res)=>res.json({ok:true,resource:'chat'}));
