import {Router} from 'express'; export const filesRouter=Router(); filesRouter.get('/files', (_req,res)=>res.json({ok:true,resource:'files'}));
