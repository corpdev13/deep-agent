import {Router} from 'express'; export const deployRouter=Router(); deployRouter.get('/deploy', (_req,res)=>res.json({ok:true,resource:'deploy'}));
