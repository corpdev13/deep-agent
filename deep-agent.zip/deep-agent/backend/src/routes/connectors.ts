import {Router} from 'express'; export const connectorsRouter=Router(); connectorsRouter.get('/connectors', (_req,res)=>res.json({ok:true,resource:'connectors'}));
