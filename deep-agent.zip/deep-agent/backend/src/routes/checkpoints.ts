import {Router} from 'express'; export const checkpointsRouter=Router(); checkpointsRouter.get('/checkpoints', (_req,res)=>res.json({ok:true,resource:'checkpoints'}));
