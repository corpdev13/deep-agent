import {Router} from 'express'; export const storageRouter=Router(); storageRouter.get('/storage', (_req,res)=>res.json({ok:true,resource:'storage'}));
