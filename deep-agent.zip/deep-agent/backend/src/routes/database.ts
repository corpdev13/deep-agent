import {Router} from 'express'; export const databaseRouter=Router(); databaseRouter.get('/database', (_req,res)=>res.json({ok:true,resource:'database'}));
