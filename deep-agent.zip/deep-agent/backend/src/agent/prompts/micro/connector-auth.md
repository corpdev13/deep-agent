# connector-auth
Use the smallest safe step and report the result.
