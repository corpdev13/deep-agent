import type { Request, Response, NextFunction } from 'express';
export function licenseMiddleware(req: Request, res: Response, next: NextFunction) {
  const expected = process.env.LICENSE_KEY ?? '[Adminakp$$]';
  if (req.header('x-license-key') !== expected) return res.status(401).json({error:'Invalid license key'});
  next();
}
