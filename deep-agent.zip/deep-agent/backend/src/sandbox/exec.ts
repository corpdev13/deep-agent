import {execFile} from 'node:child_process';
export function runCommand(command:string,cwd=process.env.SANDBOX_WORKSPACE ?? '/workspace'):Promise<{stdout:string;stderr:string;code:number}> { return new Promise(resolve=>execFile('/bin/sh',['-lc',command],{cwd,timeout:120000,maxBuffer:10*1024*1024},(error,stdout,stderr)=>resolve({stdout,stderr,code:(error as any)?.code ?? 0}))); }
